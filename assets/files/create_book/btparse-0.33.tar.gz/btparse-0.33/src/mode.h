#define START 0
#define LEX_ENTRY 1
#define LEX_STRING 2
